package com.bowl.Bowling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BowlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
