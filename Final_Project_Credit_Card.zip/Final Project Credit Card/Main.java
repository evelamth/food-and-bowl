import java.io.IOException;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
		//CreditCardInput newCard=new CreditCardInput();
		
		CreditCardInput creditCard=new CreditCardInput();
		System.out.println(creditCard.toString()); 

	}

}
